# CP1406/CP5638 - Assignment 1
## Project Plan & Small Website
### By Braydan Douglas Newman

----

[plan.html](plan.html) is in the home folder with the website and all images needed, in the [website](website) folder
the [other](other) folder contains assessment files (.pdf) and ect.