# Practical 02 - Good Websites & HTML

---

[This is a link](Practical_Guide.pdf) to the practical guide used to complete this practical