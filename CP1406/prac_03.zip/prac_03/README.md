# Practical 03 - Using CSS

---

[This is a link](Practical_Guide.pdf) to the practical guide used to complete this practical